package codes.kevinhenriquez.logforge;

import codes.kevinhenriquez.logforge.config.LogForgeConfig;
import codes.kevinhenriquez.logforge.enums.LogLevelEnum;
import codes.kevinhenriquez.logforge.error.ErrorAnalyzer;
import codes.kevinhenriquez.logforge.error.ErrorHint;
import codes.kevinhenriquez.logforge.format.LogFormatter;
import codes.kevinhenriquez.logforge.format.MessageFormatter;
import codes.kevinhenriquez.logforge.output.ConsoleWriter;
import codes.kevinhenriquez.logforge.table.LogTableFormatter;
import codes.kevinhenriquez.logforge.task.LogTask;

import static codes.kevinhenriquez.logforge.utils.AnsiColor.*;

/*
 * © 2026 LogForge. All rights reserved.
 *
 * File              : LogForge.java
 * Author            : Kevin Henriquez
 * Creation Date     : 16/05/2026
 *
 * Legal Notice:
 * Unauthorized copying, distribution, or modification of this
 * source code is strictly prohibited without explicit permission
 * from the author.
 * =============================================================================
 */
public class LogForge {
    private static final ConsoleWriter WRITER = new ConsoleWriter();
    private static final LogFormatter FORMATTER = new LogFormatter();
    private static final LogTableFormatter TABLE_FORMATTER = new LogTableFormatter();
    private static final ErrorAnalyzer ERROR_ANALYZER = new ErrorAnalyzer();

    public static void info(String message, Object... args) {
        if (shouldSkip(LogLevelEnum.INFO)) {
            return;
        }

        log(LogLevelEnum.INFO, MessageFormatter.format(message, args));
    }

    public static void success(String message, Object... args) {
        if (shouldSkip(LogLevelEnum.SUCCESS)) {
            return;
        }

        log(LogLevelEnum.SUCCESS, MessageFormatter.format(message, args));
    }

    public static void warning(String message, Object... args) {
        if (shouldSkip(LogLevelEnum.WARNING)) {
            return;
        }

        log(LogLevelEnum.WARNING, MessageFormatter.format(message, args));
    }

    public static void error(String message, Object... args) {
        if (shouldSkip(LogLevelEnum.ERROR)) {
            return;
        }

        String formatted = FORMATTER.format(
                LogLevelEnum.ERROR,
                MessageFormatter.format(message, args));

        WRITER.errorLog(formatted);
    }

    public static void error(String message, Throwable throwable) {
        if (shouldSkip(LogLevelEnum.ERROR)) {
            return;
        }

        String formatted = FORMATTER.format(
                LogLevelEnum.ERROR,
                MessageFormatter.format(message));

        WRITER.errorLog(formatted);

        if (throwable != null) {
            throwable.printStackTrace(System.err);
        }
    }

    public static void error(String message, Throwable throwable, Object... args) {
        if (shouldSkip(LogLevelEnum.ERROR)) {
            return;
        }

        String formatted = FORMATTER.format(
                LogLevelEnum.ERROR,
                MessageFormatter.format(message, args));

        WRITER.errorLog(formatted);

        if (throwable != null) {
            throwable.printStackTrace(System.err);
        }
    }

    public static void error(Throwable throwable, String message, Object... args) {
        if (shouldSkip(LogLevelEnum.ERROR)) {
            return;
        }

        String formatted = FORMATTER.format(
                LogLevelEnum.ERROR,
                MessageFormatter.format(message, args));

        WRITER.errorLog(formatted);

        if (throwable != null) {
            throwable.printStackTrace(System.err);
        }
    }

    public static void debug(String message, Object... args) {
        if (shouldSkip(LogLevelEnum.DEBUG)) {
            return;
        }

        String formatted = FORMATTER.format(
                LogLevelEnum.DEBUG,
                MessageFormatter.format(message, args));

        WRITER.debugLog(formatted);
    }

    public static void explain(Throwable throwable) {
        if (shouldSkip(LogLevelEnum.ERROR)) {
            return;
        }

        ErrorHint hint = ERROR_ANALYZER.analyze(throwable);
        String formatted = FORMATTER.format(LogLevelEnum.ERROR, hint.errorName());

        WRITER.errorLog(formatted);
        WRITER.errorLog("Location: " + hint.location());
        WRITER.errorLog("");
        if (hint.codeFrame().available()) {
            WRITER.errorLog(hint.codeFrame().format());
            WRITER.errorLog("");
        }
        WRITER.errorLog("Why:");
        WRITER.errorLog(hint.reason());
        WRITER.errorLog("");
        WRITER.errorLog("Suggestion:");
        WRITER.errorLog(hint.suggestion());
        WRITER.errorLog("");
        WRITER.errorLog("Possible fix:");
        WRITER.errorLog(hint.exampleFix().stripTrailing());
    }

    private static void log(LogLevelEnum level, String message, Object... args) {
        if (shouldSkip(level)) {
            return;
        }

        String formatted = FORMATTER.format(
                level,
                MessageFormatter.format(message, args));

        WRITER.writeLog(formatted);
    }

    public static void api(String method, String path, int status, long durationMs) {
        if (shouldSkip(LogLevelEnum.API)) {
            return;
        }

        String statusColor = status >= 500
                ? BRIGHT_RED
                : status >= 400
                ? BRIGHT_YELLOW
                : BRIGHT_GREEN;

        String message = BOLD + method + RESET
                + " " + path
                + " " + statusColor + status + RESET
                + " " + GRAY + durationMs + "ms" + RESET;

        log(LogLevelEnum.API, message);
    }

    public static void time(String label, LogTask task) {
        long start = System.currentTimeMillis();

        try {
            task.run();

            long duration  = System.currentTimeMillis() - start;
            success("{} completed in {}ms", label, duration);
        } catch (Exception e) {
            long duration  = System.currentTimeMillis() - start;
            error("Error while running {} after {}ms", e, label, duration);
        }
    }

    private static boolean shouldSkip(LogLevelEnum level) {
        return !LogForgeConfig.isEnabled()
                || level.getPriority() < LogForgeConfig.getMinimumLevel().getPriority();
    }

    public static void table(String[] headers, String[][] rows) {
        if (shouldSkip(LogLevelEnum.INFO)) {
            return;
        }

        WRITER.writeLog(TABLE_FORMATTER.format(headers, rows));
    }
}
